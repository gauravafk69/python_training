a=("k","l","m")
print(a)