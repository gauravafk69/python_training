details={
    "name":"Gaurav",
    "age": 60,
    "occupation": "hero"
}
details_age=details["age"]
print(details_age)