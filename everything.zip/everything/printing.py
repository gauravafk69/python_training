a="Hy i am gaurav."
print(a)