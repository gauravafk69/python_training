for a in range(1,3,1):
    a=int(input("Enter any number"))
    if a%2==0:
        print(a,"is even number")
    elif a%2!=0:
        print(a,"is odd number")
    else:
        print("Invalid input")