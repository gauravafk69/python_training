my_list=["block","chat","hat"]
# print(my_list)

# my_list[0]="insta"
# print(my_list)

# len
# a=len(my_list) 
# print(a)

# append 
# my_list.append("hancy")
# print(my_list)

#extend
# my_list.extend(["sexy", "naughty"])
# print(my_list)

#insert
my_list.insert(1,2)
# (1,2) 1 is index and 2 is number that is inserted
print(my_list)
