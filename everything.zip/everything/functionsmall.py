def greet():
   return "Hy Gaurav"
a=greet()
print(a)
    