a="Hello, Brother"
joined_a="+".join(a)
print(joined_a)

a="Iphone 13 pro max"
new_a=a.replace("13","14")
print(new_a)

b="hy i am gaurav   "
strip_a=a.strip()
print(strip_a)

