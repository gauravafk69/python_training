import random
a= random.randint(0,9)
print(a)